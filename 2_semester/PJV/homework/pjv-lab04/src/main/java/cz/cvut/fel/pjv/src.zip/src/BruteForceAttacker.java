package cz.cvut.fel.pjv;
public class BruteForceAttacker extends Thief {
    int temp = 0;
    @Override
    public void breakPassword(int sizeOfPassword) {
        char[] current_variant = new char[sizeOfPassword];
        get_all_Variants(sizeOfPassword, current_variant, 0, getCharacters());
    }
    public void get_all_Variants(int sizeOfPassword, char[] current_variant, int current_len, char[] characters){
        if (temp != 1){
//            System.out.println(current_variant);
            boolean open_case = tryOpen(current_variant);
            if (open_case == true){
                temp = 1;
            }
//            String len_char_Array = new String(characters);
            if (current_len < sizeOfPassword) {
                for (int i = 0; i < characters.length; i++) {
                    current_variant[current_len] = characters[i];
                    get_all_Variants(sizeOfPassword, current_variant, current_len + 1, characters);
                }
            }
        }
//        System.out.println(characters);
    }
    
}
